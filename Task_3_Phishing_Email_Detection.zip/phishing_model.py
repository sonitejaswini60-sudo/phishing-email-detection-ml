import pandas as pd
import re
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


DATASET = "phishing_email.csv"


def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"<.*?>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def find_column(df, candidates):
    for col in candidates:
        if col in df.columns:
            return col
    return None


def convert_label(value):
    value = str(value).lower().strip()
    if value in {"1", "phishing", "phish", "spam"}:
        return 1
    if value in {"0", "safe", "legitimate", "ham", "normal"}:
        return 0
    return None


def main():
    print("Loading dataset...")
    df = pd.read_csv(DATASET)

    text_col = find_column(
        df,
        ["text_combined", "email_text", "text", "body", "Email Text", "email"]
    )
    label_col = find_column(
        df,
        ["label", "Label", "class", "Class", "status"]
    )

    if text_col is None or label_col is None:
        raise ValueError(
            f"Could not find text/label columns. Available columns: {list(df.columns)}"
        )

    df = df[[text_col, label_col]].dropna()
    df["clean_text"] = df[text_col].apply(clean_text)
    df["target"] = df[label_col].apply(convert_label)
    df = df.dropna(subset=["target"])
    df["target"] = df["target"].astype(int)

    if df["target"].nunique() < 2:
        raise ValueError("Dataset must contain both Safe and Phishing emails.")

    X_train, X_test, y_train, y_test = train_test_split(
        df["clean_text"],
        df["target"],
        test_size=0.20,
        random_state=42,
        stratify=df["target"]
    )

    vectorizer = TfidfVectorizer(
        max_features=10000,
        ngram_range=(1, 2),
        stop_words="english"
    )

    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    model = LogisticRegression(max_iter=1000)
    model.fit(X_train_tfidf, y_train)

    y_pred = model.predict(X_test_tfidf)
    accuracy = accuracy_score(y_test, y_pred)

    print("\n========================================")
    print("     PHISHING EMAIL DETECTION MODEL")
    print("========================================")
    print(f"Dataset size: {len(df)}")
    print(f"Accuracy: {accuracy * 100:.2f}%\n")
    print(classification_report(
        y_test, y_pred, target_names=["Safe", "Phishing"]
    ))

    cm = confusion_matrix(y_test, y_pred)

    plt.figure(figsize=(7, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=["Safe", "Phishing"],
        yticklabels=["Safe", "Phishing"]
    )
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title("Phishing Email Detection - Confusion Matrix")
    plt.tight_layout()
    plt.savefig("confusion_matrix.png", dpi=200)
    plt.show()

    while True:
        email = input("\nEnter an email to classify (or type 'exit'): ")
        if email.lower().strip() == "exit":
            break

        email_vector = vectorizer.transform([clean_text(email)])
        prediction = model.predict(email_vector)[0]
        probabilities = model.predict_proba(email_vector)[0]
        confidence = max(probabilities) * 100

        result = "PHISHING" if prediction == 1 else "SAFE"
        print(f"Result: {result}")
        print(f"Confidence: {confidence:.2f}%")


if __name__ == "__main__":
    main()
