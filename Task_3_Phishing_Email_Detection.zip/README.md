# Phishing Email Detection Model

A machine-learning project that classifies emails as **Phishing** or **Safe** using Python and Scikit-learn.

## Features

- Train on phishing and legitimate emails
- Clean and preprocess email text
- Extract TF-IDF text features
- Train a Logistic Regression classifier
- Display accuracy and classification report
- Generate a confusion matrix
- Test a new email from the terminal

## Project Structure

```text
Task_3_Phishing_Email_Detection/
├── phishing_model.py
├── phishing_email.csv
├── requirements.txt
└── README.md
```

## Installation

```bash
pip install -r requirements.txt
```

## Dataset

Place the dataset file named:

```text
phishing_email.csv
```

in the project folder.

The CSV should contain one email-text column and one label column. The program automatically recognizes common column names such as:

- Text: `text`, `email_text`, `body`, `text_combined`
- Label: `label`, `class`, `status`

Labels can be represented as:

- `Phishing` / `Safe`
- `1` / `0`
- `Spam` / `Ham`
- `Phish` / `Legitimate`

## Run

```bash
python phishing_model.py
```

The program creates:

```text
confusion_matrix.png
```

and allows a new email to be tested from the terminal.

## Technologies

- Python
- Pandas
- Scikit-learn
- TF-IDF
- Logistic Regression
- Matplotlib
- Seaborn
